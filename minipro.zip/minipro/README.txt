TO USE openhg19, you should put the 10X data under a folder called hg19 in the same Directories.
TO USE gene, you should put the 10X data under a folder called gene_data in the same Directories.